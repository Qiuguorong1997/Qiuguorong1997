# -*- coding:utf-8 -*-

from mygame.mygame import MyGame
from mygame.apple import Apple
from mygame.snake import Snake
from mygame.astar import Astar
from mygame.settings import *
